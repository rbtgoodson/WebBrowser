﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WebBrowser.Logic;

namespace WebBrowser.UI
{
    public partial class Main : Form
    {
        public Main()
        {
            InitializeComponent();
        }

        private void webNavigation1_Load(object sender, EventArgs e)
        {

        }

        // Closes the application.
        private void exitWebBrowserToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Aubie (Web Browser): "
                          + "\n\nCPSC 2713 - Software Construction Fundamentals"
                          + "\n@author Robert Goodson (rtg0012@tigermail.auburn.edu)"
                          + "\n@version January 9, 2019");
        }

        // Creates a new tab.
        private void newTabToolStripMenuItem_Click(object sender, EventArgs e)
        {
            TabPage myTabPage = new TabPage("New Tab");
            tabControl1.TabPages.Add(myTabPage);
            
            UserControl Web = new WebNavigation();
            Web.Dock = DockStyle.Fill;
            myTabPage.Controls.Add(Web);
        }

        // Closes the current tab.
        private void closeCurrentTabToolStripMenuItem_Click(object sender, EventArgs e)
        {
            tabControl1.TabPages.Remove(tabControl1.SelectedTab);
        }

        private void manageHistoryToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var itemsForm = new HistoryManagerForm();
            itemsForm.ShowDialog();
        }

        private void manageBookmarksToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var itemsForm = new BookmarkManagerForm();
            itemsForm.ShowDialog();
        }

        private void clearHistoryToolStripMenuItem_Click(object sender, EventArgs e)
        {
            HistoryManager.ClearHistory();
        }
    }
}
