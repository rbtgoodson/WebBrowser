﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WebBrowser.Logic;

namespace WebBrowser.UI
{
    public partial class HistoryManagerForm : Form
    {
        public HistoryManagerForm()
        {
            InitializeComponent();
        }

        private void HistoryManagerForm_Load(object sender, EventArgs e)
        {
            var items = HistoryManager.GetHistoryItems();
            HistoryManagerFormListBox.Items.Clear();

            foreach (var item in items)
            {
                HistoryManagerFormListBox.Items.Add(string.Format("[{0}] {1} {2}", item.Date, item.Title, item.URL));
            }
        }

        private void SearchButton_Click(object sender, EventArgs e)
        {
            var items = HistoryManager.GetHistoryItems();

            HistoryManagerFormListBox.Items.Clear();

            foreach (var item in items)
            {
                if (item.Title.Contains(HistoryManagerTextBox.Text) || item.URL.Contains(HistoryManagerTextBox.Text))
                {
                    HistoryManagerFormListBox.Items.Add(string.Format("[{0}] {1} ({2})", item.Date, item.Title, item.URL));
                }
            }
        }

        private void DeleteButton_Click(object sender, EventArgs e)
        {
            try
            {
                string input = HistoryManagerFormListBox.GetItemText(HistoryManagerFormListBox.SelectedItem);

                HistoryManager.RemoveHistoryItem(input);
                HistoryManagerFormListBox.Items.RemoveAt(HistoryManagerFormListBox.SelectedIndex);
            }
            catch (System.ArgumentOutOfRangeException ex)
            {
                Console.WriteLine(ex.GetType().Name);
                Console.WriteLine(ex.Message);
            }
        }

        private void ClearButton_Click(object sender, EventArgs e)
        {
            HistoryManager.ClearHistory();
            HistoryManagerFormListBox.Items.Clear();
        }
    }
}
