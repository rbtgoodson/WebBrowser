﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WebBrowser.Logic;

namespace WebBrowser.UI
{
    public partial class WebNavigation : UserControl
    {
        Stack<string> backLinks = new Stack<string>();
        Stack<string> forwardLinks = new Stack<string>();

        public WebNavigation()
        {
            InitializeComponent();
            webBrowser1.ScriptErrorsSuppressed = true;
        }

        private void toolStripTextBox1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                webBrowser1.Navigate(toolStripTextBox1.Text);
                backLinks.Push(toolStripTextBox1.Text);

                Timer.Start();
                StatusLabel.Text = "Loading";
                ProgressBar.Value = 0;
            }
        }

        private void toolStripButton5_Click(object sender, EventArgs e)
        {
            webBrowser1.Navigate(toolStripTextBox1.Text);
            backLinks.Push(toolStripTextBox1.Text);

            Timer.Start();
            StatusLabel.Text = "Loading";
            ProgressBar.Value = 0;
        }

        private void toolStripButton3_Click(object sender, EventArgs e)
        {
            webBrowser1.Navigate(toolStripTextBox1.Text);

            Timer.Start();
            StatusLabel.Text = "Loading";
            ProgressBar.Value = 0;
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            try
            {
                forwardLinks.Push(toolStripTextBox1.Text);
                webBrowser1.Navigate(backLinks.Pop());

                Timer.Start();
                StatusLabel.Text = "Loading";
                ProgressBar.Value = 0;
            }
            catch (InvalidOperationException ex)
            {
                Console.WriteLine(ex.GetType().Name);
                Console.WriteLine(ex.Message);
            }
        }

        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            try
            {
                backLinks.Push(toolStripTextBox1.Text);
                webBrowser1.Navigate(forwardLinks.Pop());

                Timer.Start();
                StatusLabel.Text = "Loading";
                ProgressBar.Value = 0;
            }
            catch (InvalidOperationException ex)
            {
                Console.WriteLine(ex.GetType().Name);
                Console.WriteLine(ex.Message);
            }
        }

        private void BookmarkButton_Click(object sender, EventArgs e)
        {
            var item = new BookmarkItem();
            item.URL = toolStripTextBox1.Text;
            item.Title = webBrowser1.DocumentTitle;

            BookmarkManager.AddItemBookmark(item);
        }

        private void webBrowser1_DocumentCompleted(object sender, WebBrowserDocumentCompletedEventArgs e)
        {
            if (webBrowser1.Url.AbsoluteUri == e.Url.AbsoluteUri)
            {
                var item = new HistoryItem();
                item.URL = toolStripTextBox1.Text;
                item.Title = webBrowser1.DocumentTitle;
                item.Date = DateTime.Now.ToString("mm/dd/yyyy HH:mm:ss");
                HistoryManager.AddItemHistory(item);

                StatusLabel.Text = "Done";
                Timer.Stop();
                ProgressBar.Value = 100;
            }
        }

        private void Timer_Tick(object sender, EventArgs e)
        {
            if (this.ProgressBar.Value == 100)
            {
                Timer.Stop();
                StatusLabel.Text = "Done";
            }
            else
            {
                this.ProgressBar.Value++;
            }
        }
    }
}
