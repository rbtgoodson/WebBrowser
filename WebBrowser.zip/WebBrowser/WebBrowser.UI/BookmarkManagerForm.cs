﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WebBrowser.Logic;

namespace WebBrowser.UI
{
    public partial class BookmarkManagerForm : Form
    {
        public BookmarkManagerForm()
        {
            InitializeComponent();
        }

        private void BookmarkManagerForm_Load(object sender, EventArgs e)
        {
            var items = BookmarkManager.GetBookmarkItems();
            BookmarkManagerFormListBox.Items.Clear();

            foreach (var item in items)
            {
                BookmarkManagerFormListBox.Items.Add(string.Format("{0} ({1})", item.Title, item.URL));
            }
        }

        private void SearchButton_Click(object sender, EventArgs e)
        {
            var items = HistoryManager.GetHistoryItems();

            BookmarkManagerFormListBox.Items.Clear();

            foreach (var item in items)
            {
                if (item.Title.Contains(BookmarkManagerTextBox.Text) || item.URL.Contains(BookmarkManagerTextBox.Text))
                {
                    BookmarkManagerFormListBox.Items.Add(string.Format("[{0}] {1} ({2})", item.Date, item.Title, item.URL));
                }
            }
        }

        private void DeleteButton_Click(object sender, EventArgs e)
        {
            string input = BookmarkManagerFormListBox.GetItemText(BookmarkManagerFormListBox.SelectedItem);

            HistoryManager.RemoveHistoryItem(input);
            BookmarkManagerFormListBox.Items.RemoveAt(BookmarkManagerFormListBox.SelectedIndex);
        }

        private void ClearButton_Click(object sender, EventArgs e)
        {
            BookmarkManager.ClearBookmark();
            BookmarkManagerFormListBox.Items.Clear();
        }
    }
}
